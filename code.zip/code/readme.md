Guide to set up face recognition
Recommended OS : Any Linux LTS version
Required setup :

 - Node - APIs for frontend
 - Python >=3.6 - Recognition + Training backend
 - Packages in 'requirements.txt'
 
**Note :** 
Setting up face_recognition Python package requires dlib and CMake to work properly.

**How to set up and start the application:**

	
**Place images of faces to be recognized in  `/code/server/py/known_people/` as `jpg` files with their respective names. Make sure that `/code/server/py/data/` is empty before you start.**
 1. Do `npm i` from the root directory in terminal to install necessary node packages.
 2. `pip install` from 'requirements.txt' -> installs all required Python packages.
 3. Run the Node server by executing `npm start` .
 4. Your application should now be accessible on `localhost:3000`
 5. Click on train and wait for it to complete.
 6. Then, click on run to start recognition. 
 7. **Delete data from `/code/server/py/data/` before retraining.**